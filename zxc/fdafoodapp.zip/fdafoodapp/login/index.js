






$( document ).ready( function() {



    $( '#login' ).on( 'submit', async function( event ) {

        event.preventDefault();

        const response = await fetch( $( this ).attr( 'action' ), {

            method: $( this ).attr( 'type' ).toUpperCase(),
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify( {

                email    : $( '#email' ).val().trim(),
                password : $( '#password' ).val().trim()
            } )
        } );
        // console.log( 'response', response );

        if ( response.ok ) {

            // window.location = '/dashboard';
            // window.location = '/cte';
            window.location = '/fda';

        } else if ( response.status === 400 ) {

            const data = await response.json();

            alert( `\n\nserver message :  ${ data.message }\n` );
        } else {
            alert( '\n\nServer Error !\n' );
        }
    });



    $( '#user-list' ).on( 'change', function() {  // TODO DEBUG + 크롬 모바일 터치에서 동작안해

        $( '#email' ).val( $( this ).find( 'option:selected' ).val() );
        $( '#password' ).val( '1234' );

    // }).change();
    });



});











