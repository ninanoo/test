






// TODO tpl 그룹 카드 모양 그대로 가고 , 카드 건마다 생성일/수정일 넣어주고 , 입력 버튼 -> 수정(cte-form 페이지) + 삭제(바로 delete 아작스) 버튼으로

// TODO 우선은 default 최근 건이 아래로  ->  나중에 정렬 셀렉박스나 버튼 붙히고

function draw__cte_grp_list() {

    $.getJSON("/api/cte_grp_list", (data) => {



        console.log( '/api/cte_grp_list', data );



        const cte_grp_list = data;

        let html = '';

        for (let cte_grp of cte_grp_list) {

            let tpl_list = JSON.parse(cte_grp.tpl_list);
            let cte_list = JSON.parse(cte_grp.cte_list);

            // console.log(tpl_list);
            // console.log(cte_list);

            let cte_tree = [];  // TODO 트리 뷰로 대체할 부분

            for (let idx = 0; idx < cte_list.length; idx++) {

                let tpl = tpl_list[idx];
                let cte = cte_list[idx];

                // cte_tree.push( `(${tpl.type}) ${tpl.name} : ${ format__cte_ymd(cte.cte_ymd) } ${ cte.lotcd || '' }` );

                // cte_tree.push( `<div class="col-12 col-md-4">(${tpl.type}) ${tpl.name}</div>` );
                cte_tree.push( `<div class="col-12 col-md-3">( ${tpl.name} )</div>` );
                cte_tree.push( `<div class="col-12 col-md-9 mb-2 mb-md-0">${ format__cte_ymd(cte.cte_ymd) } &nbsp;<br class="d-md-none" />${ cte.lotcd || '' }</div>` );
            }

            html += ''
                + ` <div class="col"> `
                + `     <div class="card py-2"> `
                + `         <div class="card-body"> `
                + `             <h5 class="card-title mb-4">${cte_grp.grp_name}</h5> `
                + `             <p class="card-text"> `
                + `                 담당자 : ${cte_grp.user_name} `
                + `             </p> `

                // + `             <p class="card-text"> `
                // + `                 &nbsp; ${ cte_tree.join('<br/>&gt; ') } `
                // + `             </p> `

                + `             <div class="card-text mb-3"> `
                + `                 <div class="row row-cols-1 row-cols-md-2 g-1"> `
                + `                     ${ cte_tree.join('') } `
                + `                 </div> `
                + `             </div> `

                + `             <p class="card-text mb-0"> `
                // + `                 생성일 : ${ cte_grp.create_dt.replace('T',' ').split('.')[0] } `
                + `                 생성일 : ${ format__datetime(cte_grp.create_dt) } `
                + `             </p> `
                + `             <p class="card-text"> `
                // + `                 수정일 : ${ cte_grp.update_dt.replace('T',' ').split('.')[0] } `
                + `                 수정일 : ${ format__datetime(cte_grp.update_dt) } `
                + `             </p> `
                + `             <a href="/cte-form?tpl_grp_id=${cte_grp.tpl_grp_id}&cte_grp_id=${cte_grp.cte_grp_id}" class="card-link">수정</a> `
                + `             <a href="/api/cte_grp_delete/${cte_grp.cte_grp_id}" class="card-link" onclick="return delete__cte_grp(this)">삭제</a> `
                + `         </div> `
                + `     </div> `
                + ` </div> `
            ;
        }
        $("#cte_grp_list").prepend(html);
    });
}



function delete__cte_grp(dom) {

    if ( ! confirm('\n\nDo you really want to delete ?\n') ) return false;

    $.post( $(dom).attr('href'), {} ).done( ( data )=>{  // TODO fetch 로 응답 상태 제어

        console.log(data);

        alert('\n\nDeleted !\n');

        window.location.replace(window.location.href);

    }).fail(()=>{

        alert('\n\nTransaction Fail !\n');
    });

    return false;
}





$(document).ready(function () {



    draw__cte_grp_list();



});














