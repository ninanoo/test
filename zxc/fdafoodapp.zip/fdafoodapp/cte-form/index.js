






function draw__cte_grp() {

    $.getJSON( `/api/cte_grp/${futuresense.tpl_grp_id}/${futuresense.cte_grp_id}`, function (data) {



        console.log( `/api/cte_grp/${futuresense.tpl_grp_id}/${futuresense.cte_grp_id}`, data );



        const tpl_grp = data.tpl_grp;
        const cte_grp = data.cte_grp;

        let html = '';

        for ( let idx = 0; idx < tpl_grp.length; idx++ ) {

            const tpl = tpl_grp[idx];
            const cte = cte_grp[idx];



            if ( ! futuresense.disabled ) {

                $('#cte_grp_form').find('[type=submit]').removeClass('d-none')
            }



            html += ''
                + ` <div class="col"> `
                + `     <div class="card py-2"> `
                + `         <div class="card-body"> `
                + `             <h5 class="card-title mb-4">${tpl.name} ( ${tpl.type} )</h5> `
                + `             <fieldset name="cte" ${ futuresense.disabled && 'disabled' }>`
            ;

            if (futuresense.cte_grp_id) {  // Update
                html += ''
                    + `                 <input type="hidden" class="form-control" name="id" value="${ cte.id }">`
                ;
            } else {  // Insert
                html += ''
                    + `                 <input type="hidden" class="form-control" name="tpl_id" value="${ tpl.id }">`
                    + `                 <input type="hidden" class="form-control" name="tpl_grp_id" value="${ tpl.grp_id }">`
                    + `                 <input type="hidden" class="form-control" name="order" value="${ tpl.order }">`
                    + `                 <input type="hidden" class="form-control" name="user_id" value="${ tpl.user_id }">`
                ;
            }

            for (let kde of futuresense.kde_list) {
                if (tpl[`${kde.name}_yn`] == 'Y') {
                    html += ''
                        + `         <div class="form-floating mt-3"> `
                        + `             <input type="text" class="form-control" name="${kde.name}" `
                        + ( futuresense.cte_grp_id
                                ? ( kde.name == 'cte_ymd' ? ` data-provide="datepicker" value="${ format__cte_ymd(cte[kde.name]) }" ` : ` value="${ cte[kde.name] }" ` )
                                : ( kde.name == 'cte_ymd' ? ` data-provide="datepicker" ` : '' )
                          )
                        + `             > `
                        + `             <label for="${kde.name}">${kde.text}</label> `
                        + `         </div> `
                    ;
                }
            }
            html += ''
                + `             </fieldset>`
                + `         </div> `
                + `     </div> `
                + ` </div> `
            ;
        }
        $("#cte_grp").prepend(html);

        // $('[name="cte_ymd"]').each( (idx, dom) => $(dom).datepicker({ format: "yyyy-mm-dd" }) );  // TODO mm/dd/yyyy -> yyyy-mm-dd
    });
}





(function(){  // TODO 백단과 맞춰서 UTC / Local Time 정책

    $.fn.datepicker.defaults.format = "yyyy-mm-dd";

    // $.fn.datepicker.defaults.format = {

    //     toDisplay: (date, format, language) => `${ date.getFullYear() }-${ (date.getMonth() + 1 ).toString().padStart(2, '0') }-${ date.getDate().toString().padStart(2, '0') }`,
    //     toValue:   (date, format, language) => `${ date.getFullYear() }${ (date.getMonth() + 1 ).toString().padStart(2, '0') }${ date.getDate().toString().padStart(2, '0') }`
    // };
})();





// TODO window.* 글로벌 속성 먹일때 readonly 는 readonly 로

[
    futuresense.tpl_grp_id,
    futuresense.cte_grp_id,

    futuresense.disabled

] = (function(){  // GLOBAL

    const searchParams = new URL(window.location.href).searchParams;

    const tpl_grp_id = searchParams.get('tpl_grp_id');
    const cte_grp_id = searchParams.get('cte_grp_id');

    const disabled = searchParams.get('disabled');

    console.log(`tpl_grp_id : ${tpl_grp_id}`);
    console.log(`cte_grp_id : ${cte_grp_id}`);

    tpl_grp_id || (alert('Invalid Access !'), history.back());  // TODO 새창이나 팝업으로 들어오면 back 없어

    return [ tpl_grp_id, cte_grp_id, disabled ];
})();



$(document).keypress( event => { if (event.which == "13") event.preventDefault() } );  // GLOBAL





$(function() {





    draw__cte_grp();







    $("#cte_grp_form").on("submit", function (event) {

        event.preventDefault();



        // assert(futuresense.tpl_grp_id);

        // // $(event.currentTarget).attr('action') -> /api/cte_grp_upsert = /api/cte_grp_insert + /api/cte_grp_update
        // const url = futuresense.cte_grp_id ? `/api/cte_grp_update/${futuresense.tpl_grp_id}/${futuresense.cte_grp_id}` : `/api/cte_grp_insert/${futuresense.tpl_grp_id}`

        let url = `${ $(event.currentTarget).attr('action') }/${ futuresense.tpl_grp_id }`

        if (futuresense.cte_grp_id) url += `/${ futuresense.cte_grp_id }`

        console.log(url);



        let params = [];

        $('[name=cte]').each(function(){

            let row = {};

            $(this).find('[name]').each( function(){ row[ $(this).attr('name') ] = $(this).val() } )

            if (row['cte_ymd']) row['cte_ymd'] = row['cte_ymd'].replaceAll('-', '');

            params.push(row);
        })
        console.log(params);



        $.post( url, {'params':params} ).done( ( data )=>{  // TODO fetch 로 응답 상태 제어

            console.log(data);

            alert('\n\nTransaction Success !\n\nGo to CTE Groups page.');

            // window.location.replace("/tpl");
            // window.location.replace("/cte");
            window.location.replace(document.referrer);

        }).fail(()=>{

            alert('\n\nTransaction Fail !');
        });

        return false;  // TODO
    });





    if ( ! futuresense.disabled ) {

        $('#cte_grp_form').find('[type=submit]').removeClass('d-none')
    }





});













