





function drawShipDaysAsync() {

    $.getJSON( '/api/dashboard/ship_days', data => {

        console.log( '/api/dashboard/ship_days', data );

        new Chart( document.getElementById('ship-days'), {
            type: "bar",
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        //   position: 'top',
                        position: "bottom",
                    },
                    // title: {
                    //   display: true,
                    //   text: 'Chart.js Bar Chart'
                    // }
                },
            },
            data: {
                // labels: [ "2023-01", "2023-02", "2023-03", "2023-04", "2023-05", "2023-06", "2023-07", "2023-08", "2023-09", "2023-10", "2023-11", "2023-12" ],
                datasets: [
                    {
                        label: "김치 배송",
                        data: data,
                        parsing: {
                            xAxisKey: "yyyymm",
                            yAxisKey: "kimchi_ship_days",
                        },
                    },
                    {
                        label: "배추 배송",
                        data: data,
                        parsing: {
                            xAxisKey: "yyyymm",
                            yAxisKey: "bechu_ship_days",
                        },
                    },
                    {
                        label: "마늘 배송",
                        data: data,
                        parsing: {
                            xAxisKey: "yyyymm",
                            yAxisKey: "manul_ship_days",
                        },
                    },
                    {
                        label: "굴 배송",
                        data: data,
                        parsing: {
                            xAxisKey: "yyyymm",
                            yAxisKey: "gul_ship_days",
                        },
                    },
                ],
            },
        });
    });

}



function drawProdDaysAsync() {

    $.getJSON( '/api/dashboard/prod_days', data => {

        console.log( '/api/dashboard/prod_days', data );

        // assert( Array.isArray( data ) )

        const datasets = data.map( dataset => {

            return {
                ...dataset, parsing: { xAxisKey: "yyyymm", yAxisKey: "prod_days", }
            }
        } );

        new Chart( document.getElementById('prod-days'), {
            type: "bar",
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        //   position: 'top',
                        position: "bottom",
                    },
                    // title: {
                    //   display: true,
                    //   text: 'Chart.js Bar Chart'
                    // }
                },
            },
            data: {
                // labels: [ "2023-01", "2023-02", "2023-03", "2023-04", "2023-05", "2023-06", "2023-07", "2023-08", "2023-09", "2023-10", "2023-11", "2023-12" ],

                datasets: datasets,
            },
        });
    });

}





$(document).ready(function () {



    drawShipDaysAsync();

    drawProdDaysAsync();



});














