






// TODO circular structure 까지 직렬화 시키든가 , 데이터 얻는 방법 바꾸던가 ...  ( json-stringify-safe , IndexedDB ... )

// (_=>{  // TODO sessionStorage polyfill

//     try {

//         // (
//         //     window.futuresense
//         // ) || (
//         //     window.opener && window.opener.futuresense && ( window.futuresense = window.opener.futuresense )
//         // ) || (
//         //     window.futuresense = {}
//         // )

//         if ( window.opener && window.opener.futuresense ) {

//             sessionStorage.setItem( 'futuresense', JSON.stringify( window.opener.futuresense ) )
//         }

//     } catch( e ) {  // 팝업창 띄운 후 , 부모창 컨텍스트 변경 있으면 , 부모창 데이터 접근할때 , DOMException ( cross-origin frame )

//         console.log( e )

//     } finally {

//         if ( window.futuresense ) return

//         window.futuresense = window.opener ? JSON.parse( sessionStorage.getItem( 'futuresense' ) ) : {}
//     }

// })()





(
    window.futuresense
) || (
    window.opener && window.opener.futuresense && ( window.futuresense = window.opener.futuresense )
) || (
    window.futuresense = {}
)







// 1. 그냥 KDE 들 손으로 코드에 다 박으면서 돌리는
// 2. KDE 메타정보 기준테이블 만들고 그거랑 조인해서 돌리는  ->  아직 테이블 명세 가닥이 안보여
// 3. 시스템테이블들 사용해 테이블 스키마 인스트루멘팅

futuresense.kde_list = [  // <TOBE> kde 기준정보 테이블로 디비에 넣어놓고 쿼리해서 사용 ( 관련 메타들 ) , 국제화는 DB ? 프러퍼티파일 ?

    // { name: 'lotcd', text: 'LOTCD' },
    // { name: 'lotcd_src', text: 'LOTCD SRC' },
    // { name: 'lotcd_src_ref', text: 'LOTCD SRC REF' },
    // { name: 'office_name', text: 'OFFICE NAME' },
    // { name: 'office_reg_num', text: 'OFFICE REG NUM' },
    // { name: 'office_phone', text: 'OFFICE PHONE' },
    // { name: 'office_email', text: 'OFFICE EMAIL' },
    // { name: 'office_url', text: 'OFFICE URL' },
    // { name: 'office_addr', text: 'OFFICE ADDR' },
    // { name: 'office_gps', text: 'OFFICE GPS' },
    // { name: 'office_desc', text: 'OFFICE DESC' },
    // { name: 'prod_line_no', text: 'PROD LINE NO' },
    // { name: 'item_name', text: 'ITEM NAME' },
    // { name: 'item_type', text: 'ITEM TYPE' },
    // { name: 'item_cnt', text: 'ITEM CNT' },
    // { name: 'item_unit', text: 'ITEM UNIT' },
    // { name: 'item_desc', text: 'ITEM DESC' },
    // { name: 'cte_ymd', text: 'CTE YMD' }

    // { name: 'lotcd', text: '로트번호 ( LOTCD )' },
    // { name: 'lotcd_src', text: '로트번호 출처 ( LOTCD SRC )' },
    // { name: 'lotcd_src_ref', text: '로트번호 출처 확인처 ( LOTCD SRC REF )' },  // 공식문서번호 또는 로트번호 조회 가능한 웹사이트 주소
    // { name: 'office_name', text: '사업장 이름 ( OFFICE NAME )' },
    // { name: 'office_reg_num', text: '사업장 등록번호 ( OFFICE REG NUM )' },
    // { name: 'office_phone', text: '사업장 전화번호 ( OFFICE PHONE )' },
    // { name: 'office_email', text: '사업장 이메일 ( OFFICE EMAIL )' },
    // { name: 'office_url', text: '사업장 웹사이트 ( OFFICE URL )' },
    // { name: 'office_addr', text: '사업장 주소 ( OFFICE ADDR )' },
    // { name: 'office_gps', text: '사업장 GPS 좌표 ( OFFICE GPS )' },  // <TOBE> 지리좌표 관련 좌표값/좌표체계 로 구조화될 KDE ( GPS , GCS , UTM 좌표계 등 ... )
    // // { name: 'office_desc', text: '사업장 기타사항 ( OFFICE DESC )' },
    // { name: 'prod_line_no', text: '생산시설번호 ( PROD LINE NO )' },
    // { name: 'item_name', text: '식품 이름 ( ITEM NAME )' },
    // { name: 'item_type', text: '식품 종류 ( ITEM TYPE )' },
    // { name: 'item_cnt', text: '식품 수량 ( ITEM CNT )' },  // <TOBE> item_cnt/item_cnt_unit 과 item_weight/item_weight_unit 등으로 구조화될 KDE
    // { name: 'item_unit', text: '식품 단위 ( ITEM UNIT )' },
    // { name: 'item_price', text: '식품 가격 ( ITEM PRICE )' },  // item_price/item_price_unit KDE 추가  ->  FDA 항목아닌 커스텀 KDE
    // { name: 'item_price_unit', text: '식품 가격 단위 ( ITEM PRICE UNIT )' },  // currency_types
    // // { name: 'item_desc', text: '식품 기타사항 ( ITEM DESC )' },
    // { name: 'cte_ymd', text: 'CTE 이벤트 발생일 ( CTE YMD )' }


    { name: 'lotcd', text: '로트번호' },
    { name: 'lotcd_src', text: '로트번호 출처' },
    // { name: 'lotcd_src_ref', text: '로트번호 출처 확인처' },  // 공식문서번호 또는 로트번호 조회 가능한 웹사이트 주소
    { name: 'lotcd_src_ref', text: '로트번호 출처확인' },  // 공식문서번호 또는 로트번호 조회 가능한 웹사이트 주소
    { name: 'office_name', text: '사업장 이름' },
    { name: 'office_reg_num', text: '사업장 등록번호' },
    { name: 'office_phone', text: '사업장 전화번호' },
    { name: 'office_email', text: '사업장 이메일' },
    { name: 'office_url', text: '사업장 웹사이트' },
    { name: 'office_addr', text: '사업장 주소' },
    { name: 'office_gps', text: '사업장 GPS 좌표' },  // <TOBE> 지리좌표 관련 좌표값/좌표체계 로 구조화될 KDE ( GPS , GCS , UTM 좌표계 등 ... )
    // { name: 'office_desc', text: '사업장 기타사항' },
    { name: 'prod_line_no', text: '생산시설번호' },
    { name: 'item_name', text: '식품 이름' },
    { name: 'item_type', text: '식품 종류' },
    { name: 'item_cnt', text: '식품 수량' },  // <TOBE> item_cnt/item_cnt_unit 과 item_weight/item_weight_unit 등으로 구조화될 KDE
    { name: 'item_unit', text: '식품 단위' },
    { name: 'item_price', text: '식품 가격' },  // item_price/item_price_unit KDE 추가  ->  FDA 항목아닌 커스텀 KDE
    { name: 'item_price_unit', text: '식품 가격 단위' },  // currency_types
    // { name: 'item_desc', text: '식품 기타사항' },
    { name: 'cte_ymd', text: 'CTE 이벤트 발생일' }
]




// TODO poc 동안은 모든 데이터셑 여기서 아작스 돌리고 전부 futuresense 에 ?












// TODO datetime to yyyy-mm-dd , 날짜 라이브러리 사용 , UTC 기준 잡고 처리

function format__datetime( datetime ) {

    const dt = new Date( datetime )

    return `${ dt.getFullYear() }-${ (dt.getMonth() + 1 ).toString().padStart(2, '0') }-${ dt.getDate().toString().padStart(2, '0') } ${ dt.getHours().toString().padStart(2, '0') }:${ dt.getMinutes().toString().padStart(2, '0') }:${ dt.getSeconds().toString().padStart(2, '0') }`
}

function format__cte_ymd(yyyymmdd) {  // TODO yyyymmdd to yyyy-mm-dd , 라이브러리 가져다써

    const cte_ymd = yyyymmdd.toString();

    return (cte_ymd.length != 8) ? cte_ymd : cte_ymd.replace( /(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3' );
}
























