






function printReport() {

    // $( '#card-body' ).toggleClass( 'card-body' );
    // $( '#card' ).toggleClass( 'card' );
    $( '#ctrl-area' ).hide()

    window.print()

    $( '#ctrl-area' ).show()
    // $( '#card' ).toggleClass( 'card' );
    // $( '#card-body' ).toggleClass( 'card-body' );
}







function highlightLinkTarget( dom ) {

    $( $( dom ).attr( 'href' ) ).removeClass( 'highlight' ).addClass( 'highlight' )

    setTimeout( _=> $( $( dom ).attr( 'href' ) ).removeClass( 'highlight' ), 3000 )

    // $( $( dom ).attr( 'href' ) ).fadeIn()

}







function draw__cte_grp_list() {



    function traverse( treenode, level ) {  // treenode == cte_grp

        if ( ! treenode ) return ''

        futuresense.cte_grp_map[ treenode.cte_grp_id ].order = level

        let html = ''
            + ` <tbody> `
            + '     <tr class="caption"> '
            + `         <td colspan="5" rowspan="2" class="align-bottom pb-1"><span class="site me-3">${ level }. ${ treenode.grp_name }</span> ( 담당자 ) ${ treenode.user_name }</td> `
            + `         <td colspan="3" class="text-end pt-5">( 생성일 ) <span class="ms-2">${ format__datetime( treenode.create_dt ) }</span></td> `
            + '     </tr> '
            + '     <tr class="caption"> '
            // + `         <td colspan="5" class="">( 담당자 ) <span class="ms-2">${ treenode.user_name }</span></td> `
            + `         <td colspan="3" class="text-end pb-2">( 수정일 ) <span class="ms-2">${ format__datetime( treenode.update_dt ) }</span></td> `
            + '     </tr> '
            + '     <tr class="thead text-secondary border-top"> '
            + '         <th class="text-center">순서</th> '
            + '         <th class="text-center">CTE</th> '
            + '         <th>CTE 발생일</th> '
            + '         <th>위치</th> '
            + '         <th>식품</th> '
            + '         <th colspan="2">로트번호</th> '
            + '         <th class="text-end">KDE 입력률</th> '
            + '     </tr> '
        ;

        let ratio, aggregated_ratio = 0

        for ( let fdaEvent of treenode.cte_list ) {

            let cte = futuresense.cte_map[ fdaEvent.id ]

            aggregated_ratio += ( ratio = +futuresense.cte_ratio_map[ cte.id ].ratio )

            html += ''
                + ` <tr> `
                + `     <td class="cte-order">${ cte.order }</td> `
                + `     <td class="cte-name"><a href="#cte__${ cte.id }" onclick="highlightLinkTarget(this)">${ futuresense.tpl_map[ cte.tpl_id ].name }</a></td> `
                + `     <td>${ format__cte_ymd( cte.cte_ymd ) }</td> `
                + `     <td>${ cte.office_name }</td> `
                + `     <td>${ cte.item_name }</td> `
                + `     <td colspan="2">${ cte.lotcd || '' }</td> `
                + `     <td class="cte-ratio">${ ratio.toFixed( 4 ) }</td> `
                + ` </tr> `
            ;
        }

        aggregated_ratio = aggregated_ratio / treenode.cte_list.length || 0

        html += ''
            + '     <tr class="tfoot text-secondary text-end"> '
            + `         <td colspan="5" class=""></td> `
            + `         <td colspan="1" class=""></td> `
            + `         <td class="pe-1 border-bottom">싸이트 입력률 : </td> `
            + `         <td class="border-bottom ${ ( aggregated_ratio < 0.8 ) ? 'text-danger' : 'text-success' }">${ aggregated_ratio.toFixed( 4 ) }</td> `
            + '     </tr> '
            + ' </tbody> '
        ;

        for ( let recv_cte of treenode.recv_cte_list ) html += traverse( recv_cte.link_grp, ++level )

        return html
    }



    // $( '#cte_grp_list' ).prepend( traverse( futuresense.trc, 1 ) )
    $( '#cte_grp_list' ).append( traverse( futuresense.trc, 1 ) )



}





function draw__cte_list() {

    let html = '';

    for ( let cte of Object.values( futuresense.cte_map ).reverse() ) {

        const tpl = futuresense.tpl_map[ cte.tpl_id ]

        const cte_grp = futuresense.cte_grp_map[ cte.grp_id ]

        const cte_ratio = futuresense.cte_ratio_map[ cte.id ]


        html += ''
            + ` <div id="cte__${ cte.id }" class="col mt-5"> `
            // + `     <div class="card py-2"> `
            // + `         <div class="card-body"> `
            + `             <div class="d-flex border-bottom border-1 mb-4"> `
            + `                 <h5 class="flex-grow-1">${ cte_grp.order }-${ cte.order }. ${ cte_grp.grp_name } - ${tpl.name} ( ${tpl.type} )</h5> `
            + `                 <div class="text-nowrap ms-2 fs-5 ${ ( (cte_ratio.entered / cte_ratio.assigned) < 0.8 ) ? 'text-danger' : 'text-primary' }">${ cte_ratio.entered } / ${ cte_ratio.assigned }</div> `
            + `             </div> `
            // + `             <fieldset name="cte" ${ futuresense.disabled && 'disabled' }>`
            + `             <div>`
        ;

        for (let kde of futuresense.kde_list) {

            if ( tpl[`${kde.name}_yn`] == 'Y' ) {

                html += ''
                    + `         <div class="row mt-2"> `
                    + `             <div class="col-4"><div class="${ cte[kde.name] ? 'bg-success' : 'bg-danger' } text-white opacity-100 px-2 py-1">${ kde.text }</div></div> `
                    + `             <div class="col-8 py-1">${ kde.name == 'cte_ymd' ? format__cte_ymd( cte[kde.name] ) : cte[kde.name] }</div> `
                    + `         </div> `
                ;
            }
        }

        html += ''
            + `             </div>`
            // + `             </fieldset>`
            // + `         </div> `
            // + `     </div> `
            + ` </div> `
        ;
    }

    $( '#cte_list' ).prepend( html )
}





$(function() {



    const report_date = new Date()

    const params = new URLSearchParams( document.location.search )



    const title = params.get( 'title' )

    $( 'title' ).text( `FS-FT-RPT-${ report_date.getFullYear() }${ ( report_date.getMonth() + 1 ).toString().padStart(2, '0') }${ report_date.getDate().toString().padStart(2, '0') }-${ report_date.getHours().toString().padStart(2, '0') }${ report_date.getMinutes().toString().padStart(2, '0') }${ report_date.getSeconds().toString().padStart(2, '0') }--${ title }` )



    console.log( 'futuresense.cte_grp_list', futuresense.cte_grp_list )



    futuresense.trc_idx = params.get( 'trc_idx' )

    console.log( 'futuresense.trc_idx : ', futuresense.trc_idx )

    futuresense.trc = futuresense.trc_list[ futuresense.trc_idx ]

    console.log( 'futuresense.trc_list', futuresense.trc_list )
    console.log( 'futuresense.trc', futuresense.trc )





    $( '#report-title' ).text( title )
    $( '#report-date' ).text( format__datetime( report_date ) )





    $( '#user-name' ).text( futuresense.user_data.name )
    $( '#user-address' ).text( futuresense.user_data.address )
    $( '#user-phone' ).text( futuresense.user_data.phone )
    $( '#user-email' ).text( futuresense.user_data.email )








    ;(_=>{

        function traverse( treenode, lastcb ) {  // treenode == cte_grp

            if ( ! treenode ) return

            futuresense.cte_grp_map[ treenode.cte_grp_id ] = treenode

            ++counter

            $.getJSON( `/api/cte_grp/${treenode.tpl_grp_id}/${treenode.cte_grp_id}`, function (data) {

                for ( let tpl of data.tpl_grp ) futuresense.tpl_map[ tpl.id ] = tpl
                for ( let cte of data.cte_grp ) futuresense.cte_map[ cte.id ] = cte

                if ( 0 == --counter ) lastcb()
            })

            for ( let recv_cte of treenode.recv_cte_list ) traverse( recv_cte.link_grp, lastcb )
        }



        // trc_list 순회돌면서 counter 올리고 , api/cte_grp/{tpl_grp_id}/{cte_grp_id} 바로바로 보내고 , 각자 도착해서 counter 내리고 , counter == 0 이면 , 다음으로
        // -> trc_list 재귀 순회 콜과 아작스 콜백 간 counter 경쟁 -> 첫 아작스 콜백이 다음 재귀 콜보다 빠르면 탐지못하는 예외 -> 외부 영향 받는 특이 상황아니면 ... 지금은 그냥 넘어가

        futuresense.tpl_map = {}  // tpl_id : tpl {}
        futuresense.cte_map = {}  // cte_id : cte {}

        futuresense.cte_grp_map = {}    // cte_grp_id : cte_grp {}
        futuresense.cte_ratio_map = {}  // cte_id : cte_ratio {}



        let counter = 0

        traverse( futuresense.trc, _=> {

            // console.log( 'futuresense.tpl_map', futuresense.tpl_map )
            // console.log( 'futuresense.cte_map', futuresense.cte_map )

            $.getJSON( `/api/kde_ratio_list?q=${ Object.keys( futuresense.cte_map ).join() }`, function (data) {

                // console.log( `/api/kde_ratio_list?q=${ Object.keys( futuresense.cte_map ).join() }`, data );

                for ( let cte_ratio of data ) futuresense.cte_ratio_map[ cte_ratio.id ] = cte_ratio

                console.log( 'futuresense', futuresense )

                draw__cte_grp_list()  // 아작스 다 받았고 , 화면 드로잉
                draw__cte_list()
            })
        })



    })()









});













