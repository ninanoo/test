






function draw__tpl_grp_list() {

    $.getJSON("/api/tpl_grp_list", (data) => {



        console.log( '/api/tpl_grp_list', data );



        const tpl_grp_list = data;

        let html = '';

        for (let tpl_grp of tpl_grp_list) {

            let tpl_list = [];

            for (let tpl of JSON.parse(tpl_grp.tpl_list)) {

                tpl_list.push( `( ${tpl.type} ) ${tpl.name}` );
            }
            html += ''
                + ` <div class="col"> `
                + `     <div class="card py-2"> `
                + `         <div class="card-body"> `
                + `             <h5 class="card-title mb-4">${tpl_grp.grp_name}</h5> `
                + `             <p class="card-text"> `
                + `                 담당자 : ${tpl_grp.user_name} `
                + `             </p> `
                + `             <p class="card-text"> `
                // + `                 CTEs : ${ tpl_list.join(' > ') } `
                + `                 ${ tpl_list.join('<br/>') } `
                + `             </p> `
                + `             <a href="/cte-form?tpl_grp_id=${tpl_grp.grp_id}" class="card-link">입력</a> `
                + `         </div> `
                + `     </div> `
                + ` </div> `
            ;
        }
        $("#tpl_grp_list").prepend(html);
    });
}





$(document).ready(function () {



    draw__tpl_grp_list();



});














