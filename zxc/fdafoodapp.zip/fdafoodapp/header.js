






$( document ).ready( function() {



    // TODO 뒤로가기 -> 세로고침

    // if ('referrer' in document) {
    //     window.location = document.referrer;
    //     /* OR */
    //     //location.replace(document.referrer);
    // } else {
    //     window.history.back();
    // }



    ( async _=>{  // TODO 상태 헨들링 ( 예외 처리 )



        const header_resp = await fetch( '/header.html', { method: 'GET' } );
        const header_html = await header_resp.text();

        // console.log( '/header.html', header_resp, header_html );

        $( 'body' ).prepend( header_html );

        $( `.nav-link[href="${ window.location.pathname }"]` ).addClass( 'active' );



        const user_resp = await fetch( '/api/user/info', { method: 'GET', cache: 'no-store' } );
        const user_data = await user_resp.json();

        // console.log( '/user/info', user_resp, user_data );

        futuresense.user_data = user_data

        if ( user_resp.ok ) {

            $( '#user-name' ).text( user_data.name );
            $( '#logout' ).removeClass( 'd-none' );

        } else {

            $( '#user-name' ).text( 'Login required' );
            $( '#login' ).removeClass( 'd-none' );
        }



        // $( '#logout' ).on( 'click', async function( event ) {

        //     event.preventDefault();

        //     const response = await fetch( $( this ).attr( 'href' ), { method: 'GET' } );

        //     if ( response.ok ) { window.location = '/login' } else { /* TODO */ }
        // });



    })();



});










