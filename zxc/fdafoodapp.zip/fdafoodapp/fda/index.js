






function make__cte_grp_tree( cte_grp_list ) {  // once call



    function make_links( tree ) {

        // <규칙> 반드시 , 수확 ~ 출고 / 입고 ~ 출고 , 의 최소 2개 CTE 갖음  ->  assert( cte_list.length > 2 )

        // <규칙> tree 간 연결은 , 반드시 입고/출고 통한다고 , 가정 !  ->  리프(RECV) / 루트(SHIP) 통해서만 연결



        // console.assert( ! tree.recv_cte_list, '! tree.recv_cte_list  ->  false' );

        if ( tree.recv_cte_list ) return tree;  // TODO 있거나없거나말고 아예 한번씩만 진입하게



        let tpl_list = tree.tpl_list = JSON.parse( tree.tpl_list );
        let cte_list = tree.cte_list = JSON.parse( tree.cte_list );

        // console.log('tpl_list : ', tpl_list);
        // console.log('cte_list : ', cte_list);

        tree.recv_cte_list = [];                          // RECV  ,,,  cf> HARV -> cte_grp.recv_cte_list.length == 0
        tree.ship_cte = cte_list[ cte_list.length - 1 ];  // SHIP ( 업체-루트 )  ,,,  <TODO> cte_grp_id 꺼꾸로 잡았어 -> 뒤집어

        tree.ship_cte.this_grp = tree;  // TODO 역참조까지 걸어야되나 ?

        for ( let idx = 0 ; idx < tpl_list.length - 1 ; idx++ ) {

            if ( 'RECV' === tpl_list[idx].type ) {

                cte_list[idx].this_grp = tree;  // TODO

                tree.recv_cte_list.push( cte_list[idx] );
            }
        }
        // console.log('recv_cte_list : ', tree.recv_cte_list);
        // console.log('ship_cte : '     , tree.ship_cte);

        return tree;
    }



    function traverse( trc_list, tree ) {

        make_links( tree );  // TODO

        for ( let recv_cte of tree.recv_cte_list ) {

            if ( ! recv_cte.lotcd ) continue;

            for ( let idx = 0 ; idx < trc_list.length ; idx++ ) {

                let ship_cte = make_links( trc_list[idx] ).ship_cte;

                if ( ! ship_cte.lotcd ) continue;

                if ( ship_cte.lotcd === recv_cte.lotcd ) {  // 출고 ( ship_cte.lotcd ) -> 입고 ( recv_cte.lotcd )

                    recv_cte.link_grp = ship_cte.this_grp;  // downstream
                    ship_cte.link_grp = recv_cte.this_grp;  //   upstream

                    traverse( trc_list, trc_list.splice( idx, 1 )[0] );

                    break;
                }
            }
        }
    }



    let trc_list = [ ...cte_grp_list ];

    let root;  // TODO

    while ( ( trc_list.length > 0 ) && ( trc_list[0].mark !== true ) ) {  // TODO

        root = trc_list.shift();

        root.mark = true;  // TODO

        traverse( trc_list, root );

        trc_list.push( root );  // TODO
    }

    return trc_list;
}





function draw__cte_grp_list() {

    $.getJSON( "/api/cte_grp_list", data => {

        function draw__cte_grp_card( cte_grp, tag ) {

            let tpl_list = cte_grp.tpl_list;
            let cte_list = cte_grp.cte_list;

            // console.log(tpl_list);
            // console.log(cte_list);

            let cte_tree = [];  // TODO 한 업체 내의 CTE 들 -> 트리 뷰로 대체할 부분

            // for (let idx = 0; idx < cte_list.length; idx++) {
            for ( let idx = cte_list.length - 1 ; idx >= 0 ; idx-- ) {

                if ( ! 'RECV|SHIP'.includes( tpl_list[idx].type ) ) continue;

                let tpl = tpl_list[idx];
                let cte = cte_list[idx];

                // cte_tree.push( `(${tpl.type}) ${tpl.name} : ${ format__cte_ymd(cte.cte_ymd) } ${ cte.lotcd || '' }` );

                // cte_tree.push( `<div class="col-12 col-md-4">(${tpl.type}) ${tpl.name}</div>` );
                cte_tree.push( `<div class="col-12 col-md-3">( ${tpl.name} )</div>` );
                cte_tree.push( `<div class="col-12 col-md-9 mb-2 mb-md-0">${ format__cte_ymd(cte.cte_ymd) } &nbsp;<br class="d-md-none" />${ cte.lotcd || '' }</div>` );
            }

            return  ''
                + ` <div class="col"> `
                + `     <div class="card py-2"> `
                + `         <div class="card-body"> `

                // + `             <h5 class="card-title mb-4">${cte_grp.grp_name}</h5> `

                + `             <h5 class="card-title mb-4"> `
                // + `                 <a href="/cte-form?tpl_grp_id=${cte_grp.tpl_grp_id}&cte_grp_id=${cte_grp.cte_grp_id}&disabled=true" class="card-link text-decoration-none">${cte_grp.grp_name}</a> `
                + `                 <a href="/cte-form?tpl_grp_id=${cte_grp.tpl_grp_id}&cte_grp_id=${cte_grp.cte_grp_id}" class="card-link text-decoration-none">${cte_grp.grp_name}</a> `
                + `                 &nbsp; <span class="badge bg-warning text-dark">${tag}</span> `
                + `             </h5> `

                + `             <p class="card-text"> `
                + `                 담당자 : ${cte_grp.user_name} `
                + `             </p> `

                // + `             <p class="card-text"> `
                // + `                 &nbsp; ${ cte_tree.join('<br/>&gt; ') } `
                // + `             </p> `

                + `             <div class="card-text mb-3"> `
                + `                 <div class="row row-cols-1 row-cols-md-2 g-1"> `
                + `                     ${ cte_tree.join('') } `
                + `                 </div> `
                + `             </div> `

                // + `             <p class="card-text mb-0"> `
                // // + `                 생성일 : ${ cte_grp.create_dt.replace('T',' ').split('.')[0] } `
                // + `                 생성일 : ${ format__datetime(cte_grp.create_dt) } `
                // + `             </p> `
                // + `             <p class="card-text"> `
                // // + `                 수정일 : ${ cte_grp.update_dt.replace('T',' ').split('.')[0] } `
                // + `                 수정일 : ${ format__datetime(cte_grp.update_dt) } `
                // + `             </p> `
                // + `             <a href="/cte-form?tpl_grp_id=${cte_grp.tpl_grp_id}&cte_grp_id=${cte_grp.cte_grp_id}&disabled=true" class="card-link">보기</a> `
                + `         </div> `
                + `     </div> `
                + ` </div> `
            ;
        }



        console.log( '/api/cte_grp_list', data );



        const cte_grp_list = data;

        const trc_list = make__cte_grp_tree( cte_grp_list );

        console.log( 'trc_list', trc_list );

        futuresense.cte_grp_list = cte_grp_list;
        futuresense.trc_list = trc_list;



        // TODO 트리 모양 그려주는 UI 라이브러리 사용

        function preorder( grp, lvl, tag ) {

            if ( ! grp ) return '';

            let html = draw__cte_grp_card( grp, tag );

            grp.recv_cte_list.forEach( ( recv_cte, idx )=>{

                html += preorder( recv_cte.link_grp, lvl + 1, `${ tag } L${ lvl + 1 }:${ idx }` )
            });
            return html;
        }
        let html = '';

        trc_list.forEach( ( grp, idx ) => {

            // html += `<p class="h1 pt-3 my-4">( ${ format__cte_ymd( grp.ship_cte.cte_ymd ) } ) ${ grp.ship_cte.lotcd }</p>` +
            // html += `<p class="h1 pt-3 my-4">( ${ format__cte_ymd( grp.ship_cte.cte_ymd ) } ) ${ grp.ship_cte.lotcd } <i class="bi-printer-fill text-primary"></i></p>` +
            html += `<p class="h1 pt-3 my-4">( ${ format__cte_ymd( grp.ship_cte.cte_ymd ) } ) ${ grp.ship_cte.lotcd } ` +
                        `<a href="/fda-report?trc_idx=${ idx }&title=${ grp.ship_cte.lotcd }" onclick="return openFdaReportPopup(this)" class="text-decoration-none">` +
                            `<i class="bi-printer-fill text-primary" alt="보고서출력"></i>` +
                        '</a>' +
                    '</p>' +
                    '<div class="row row-cols-1 row-cols-md-2 row-cols-xl-3 g-3 mb-5">' +
                        preorder( grp, 0, `FDA L${ 0 }:${ idx }` ) +
                    '</div>'
        });
        $("#cte_grp_list").prepend( html );
    });
}





function openFdaReportPopup(dom) {



    // TODO 팝업에서 여기꺼 cte_grp_list / trc_list 참조사용하고 , cte-form 화면 데이터 API 는 따로 팝업에서 콜하고



    // fullscreen=yes

    let reportPopup = window.open( $(dom).attr('href'), '_blank',

        // `width=${screen.availWidth},` +
        // `height=${screen.availHeight},` +

        `width=700vw,` +
        `height=1000vh,` +

        'titlebar=yes,' +
        'location=no,' +
        'toolbar=no,' +
        'menubar=no,' +
        'status=no,' +
        'scrollbars=yes,' +
        'resizable=yes'
    )

    return false;
}







$(document).ready(function () {



    draw__cte_grp_list();



});














